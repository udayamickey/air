package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.utility.DBConnection;

public class UserDaoImpl implements IUserDao{
	@Override
	public void addUserDetails(UserBean user) throws ARSException {
		// TODO Auto-generated method stub
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
						("insert into users values(?,?,?,?)")
				
				){
			System.out.println(user.getUserName());
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getRole());
			preparedStatement.setLong(4, user.getMobileNo());
			int n=preparedStatement.executeUpdate();
			if(n!=0){
				
			}
			
		
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}

	@Override
	public UserBean getUserDetails(String username) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from users where username=?")){
			preparedStatement.setString(1, username);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				UserBean user=new UserBean();
				user.setUserName(resultSet.getString(1));
				user.setPassword(resultSet.getString(2));
				user.setRole(resultSet.getString(3));
				user.setMobileNo(resultSet.getLong(4));
				return user;
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean isValidUser(String username, String password)
			throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedstatement = connection.prepareStatement("select * from users where username=? and password=?")){
			preparedstatement.setString(1, username);
			preparedstatement.setString(2, password);
			ResultSet rs=preparedstatement.executeQuery();
			
			if(rs.next()){
				return true;
			}
		}catch(SQLException e){
			
		}
		return false;
	}

	@Override
	public String getUserRole(String username, String password)
			throws ARSException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement =connection.prepareStatement("select role from users where username=? and password = ?")
				
				){
			
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				String role = resultSet.getString(1);
				return role;
			}
			
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}

	
	
}

	

	
	


